import tkinter

fenetre = tkinter.Tk()
fenetre['bg'] = 'white'
fenetre.title("Amplificateur non-inverseur")
fenetre.geometry("600x600")
fenetre.resizable(0, 0)
fenetre.iconbitmap("cube.ico")
logo = tkinter.PhotoImage(file='AOP.PNG')

cnv = tkinter.Canvas(fenetre, width=570, height=570, bg="white", highlightbackground="white")
cnv.pack()

cnv.create_image(350, 240, image=logo)

entree1 = tkinter.Entry(fenetre, width=10, bg="azure")
lb1 = tkinter.Label(fenetre, text='Ve=', bg="white")
cnv.create_window(15, 220, window=lb1)
cnv.create_window(80, 220, window=entree1)

entree3 = tkinter.Entry(fenetre, width=10, bg="azure")
cnv.create_window(300, 290, window=entree3)

entree2 = tkinter.Entry(fenetre, width=10, bg="azure")
cnv.create_window(400, 255, window=entree2)

lb2 = tkinter.Label(fenetre, text='Vs', bg="azure")
cnv.create_window(550, 220, window=lb2)


def add():
    global e, p1, p2
    try:  # Lorsque un des ENTRY est vide ou les deux sont vide cela engendre une erreur et pour empêcher cette erreur, nous utilisons les exceptions
        Ve = entree1.get()
        R1 = entree3.get()
        R2 = entree2.get()

        """ 
        ou: 

        Ve = float(entree1.get()) 
        R1 = float(entree3.get()) 
        R2 = float(entree2.get())  

        """

        e = float(Ve)
        p1 = float(R1)
        p2 = float(R2)
        vs = 0.0

        sr = ((p1 + p2) * e)
        vs = sr / p1
        vs = round(vs, 2)

        lb3 = tkinter.Label(fenetre, text=vs, bg='yellow')
        cnv.create_window(550, 247, window=lb3)
    except:
        pass


btn = tkinter.Button(fenetre, text='OUTPUT', command=add, bg='green')
cnv.create_window(285, 550, window=btn)

btn_quit = tkinter.Button(fenetre, text='Quiter', command=fenetre.destroy, bg='red')
cnv.create_window(400, 550, window=btn_quit)

fenetre.mainloop()